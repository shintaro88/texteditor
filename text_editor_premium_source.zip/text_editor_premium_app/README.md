# Text Editor Premium

Aplikasi Android text editor sederhana berbasis Flutter.

## Fitur MVP

- Membuat catatan/file teks baru
- Mengedit catatan lama
- Menyimpan catatan sebagai file `.txt`
- Menampilkan daftar catatan
- Menghapus catatan
- Penyimpanan lokal di internal storage aplikasi
- Tidak membutuhkan permission storage Android

## Fitur Free

- Maksimal 10 file/catatan
- Buat, edit, simpan, dan hapus catatan
- UI Material Design sederhana

## Fitur Premium Dummy

- Unlimited file/catatan
- Status premium disimpan menggunakan `shared_preferences`
- Tombol upgrade masih dummy untuk MVP
- Struktur kode disiapkan agar nanti mudah diganti ke Google Play Billing

## Struktur Project

```text
lib/
├─ main.dart
├─ models/
│  └─ note_file.dart
├─ screens/
│  ├─ home_screen.dart
│  ├─ editor_screen.dart
│  └─ premium_screen.dart
└─ services/
   ├─ file_service.dart
   └─ premium_service.dart
```

## Cara Build APK dari GitHub Actions

1. Extract ZIP ini.
2. Upload semua isi folder ke repository GitHub.
3. Pastikan branch utama bernama `main`.
4. Buka tab **Actions**.
5. Pilih workflow **Build Android APK**.
6. Klik **Run workflow**, atau push commit ke branch `main`.
7. Setelah proses selesai, download artifact bernama `text-editor-premium-debug-apk`.

APK debug akan tersedia dari path artifact:

```text
build_workspace/build/app/outputs/flutter-apk/app-debug.apk
```

## Kenapa Tidak Ada Folder Android di ZIP Ini?

ZIP ini sengaja dibuat sebagai source Flutter bersih. Workflow GitHub Actions akan menjalankan:

```bash
flutter create --project-name text_editor_premium --org com.stevanus --platforms=android build_workspace
```

Lalu source code aplikasi akan disalin ke workspace tersebut dan APK dibuild dari sana.

Pendekatan ini lebih aman untuk menghindari error restore/build akibat Android scaffold manual, Gradle wrapper yang tidak lengkap, atau konfigurasi Android yang tidak sinkron dengan Flutter stable.

## Cara Menjalankan Lokal

Jika ingin menjalankan di laptop/PC yang sudah ada Flutter SDK:

```bash
flutter create --project-name text_editor_premium --org com.stevanus --platforms=android .
flutter pub get
flutter run
```

## Cara Build APK Lokal

```bash
flutter create --project-name text_editor_premium --org com.stevanus --platforms=android .
flutter pub get
flutter build apk --debug
```

APK lokal akan berada di:

```text
build/app/outputs/flutter-apk/app-debug.apk
```

## Catatan

Premium masih dummy. Untuk produksi, fitur premium perlu diganti ke integrasi resmi Google Play Billing, misalnya melalui package `in_app_purchase`, dan sebaiknya dilakukan validasi pembelian di backend.

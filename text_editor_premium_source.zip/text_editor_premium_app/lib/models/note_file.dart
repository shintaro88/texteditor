class NoteFile {
  const NoteFile({
    required this.name,
    required this.path,
    required this.modifiedAt,
    required this.sizeBytes,
  });

  final String name;
  final String path;
  final DateTime modifiedAt;
  final int sizeBytes;

  String get displayName => name.replaceFirst(
        RegExp(r'\.txt$', caseSensitive: false),
        '',
      );
}

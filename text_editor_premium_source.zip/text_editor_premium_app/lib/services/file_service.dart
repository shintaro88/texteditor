import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../models/note_file.dart';

class FileService {
  static const String notesFolderName = 'notes';

  Future<Directory> getNotesDirectory() async {
    final appDirectory = await getApplicationDocumentsDirectory();
    final notesDirectory = Directory('${appDirectory.path}/$notesFolderName');

    if (!await notesDirectory.exists()) {
      await notesDirectory.create(recursive: true);
    }

    return notesDirectory;
  }

  Future<List<NoteFile>> getNoteFiles() async {
    final directory = await getNotesDirectory();
    final entities = directory.listSync().whereType<File>().where(
          (file) => file.path.toLowerCase().endsWith('.txt'),
        );

    final notes = <NoteFile>[];

    for (final file in entities) {
      final stat = await file.stat();
      final name = file.uri.pathSegments.last;

      notes.add(
        NoteFile(
          name: name,
          path: file.path,
          modifiedAt: stat.modified,
          sizeBytes: stat.size,
        ),
      );
    }

    notes.sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
    return notes;
  }

  Future<String> readNote(String path) async {
    final file = File(path);

    if (!await file.exists()) {
      throw const FileSystemException('File tidak ditemukan');
    }

    return file.readAsString();
  }

  Future<File> saveNote({
    required String fileName,
    required String content,
    String? originalPath,
  }) async {
    final directory = await getNotesDirectory();
    final sanitizedName = sanitizeFileName(fileName);
    final targetFile = File('${directory.path}/$sanitizedName.txt');

    await targetFile.writeAsString(content);

    if (originalPath != null && originalPath != targetFile.path) {
      final originalFile = File(originalPath);
      if (await originalFile.exists()) {
        await originalFile.delete();
      }
    }

    return targetFile;
  }

  Future<void> deleteNote(String path) async {
    final file = File(path);

    if (await file.exists()) {
      await file.delete();
    }
  }

  String sanitizeFileName(String input) {
    final cleaned = input.trim().replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    final compacted = cleaned.replaceAll(RegExp(r'\s+'), ' ');
    final withoutExtension = compacted.toLowerCase().endsWith('.txt')
        ? compacted.substring(0, compacted.length - 4)
        : compacted;

    return withoutExtension.isEmpty ? 'untitled' : withoutExtension;
  }
}

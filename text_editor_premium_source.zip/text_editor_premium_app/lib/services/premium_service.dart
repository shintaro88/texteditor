import 'package:shared_preferences/shared_preferences.dart';

class PremiumService {
  static const String keyIsPremium = 'isPremium';

  Future<bool> isPremium() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(keyIsPremium) ?? false;
  }

  Future<void> upgradeToPremium() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(keyIsPremium, true);
  }

  Future<void> resetPremium() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(keyIsPremium, false);
  }
}

import 'package:flutter/material.dart';

import '../services/premium_service.dart';

class PremiumScreen extends StatefulWidget {
  const PremiumScreen({super.key});

  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {
  final PremiumService _premiumService = PremiumService();
  bool _isProcessing = false;

  Future<void> _upgrade() async {
    setState(() => _isProcessing = true);
    await _premiumService.upgradeToPremium();

    if (!mounted) return;

    setState(() => _isProcessing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Premium berhasil diaktifkan.')),
    );
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Upgrade Premium'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.workspace_premium_outlined,
                    size: 48,
                    color: colorScheme.onPrimaryContainer,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Text Editor Premium',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: colorScheme.onPrimaryContainer,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Buka batasan versi gratis dan siapkan pondasi untuk fitur premium berikutnya.',
                    style: TextStyle(color: colorScheme.onPrimaryContainer),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const _PremiumFeatureTile(
              icon: Icons.all_inclusive,
              title: 'Unlimited file',
              description: 'Buat dan simpan catatan tanpa batas 10 file.',
            ),
            const _PremiumFeatureTile(
              icon: Icons.search,
              title: 'Search catatan',
              description: 'Disiapkan untuk pencarian isi catatan pada tahap berikutnya.',
            ),
            const _PremiumFeatureTile(
              icon: Icons.picture_as_pdf_outlined,
              title: 'Export PDF',
              description: 'Disiapkan untuk kebutuhan export catatan ke PDF.',
            ),
            const _PremiumFeatureTile(
              icon: Icons.lock_outline,
              title: 'Lock catatan',
              description: 'Disiapkan untuk fitur PIN/password pada catatan penting.',
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _isProcessing ? null : _upgrade,
              icon: _isProcessing
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.lock_open_outlined),
              label: Text(
                _isProcessing ? 'Memproses...' : 'Aktifkan Premium Dummy',
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Catatan: tombol ini masih dummy untuk MVP. Nanti bisa diganti ke Google Play Billing menggunakan package in_app_purchase.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}

class _PremiumFeatureTile extends StatelessWidget {
  const _PremiumFeatureTile({
    required this.icon,
    required this.title,
    required this.description,
  });

  final IconData icon;
  final String title;
  final String description;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(description),
      ),
    );
  }
}

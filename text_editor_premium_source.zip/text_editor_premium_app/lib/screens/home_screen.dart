import 'package:flutter/material.dart';

import '../models/note_file.dart';
import '../services/file_service.dart';
import '../services/premium_service.dart';
import 'editor_screen.dart';
import 'premium_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const int freeFileLimit = 10;

  final FileService _fileService = FileService();
  final PremiumService _premiumService = PremiumService();

  List<NoteFile> _notes = [];
  bool _isPremium = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);

    try {
      final notes = await _fileService.getNoteFiles();
      final isPremium = await _premiumService.isPremium();

      if (!mounted) return;

      setState(() {
        _notes = notes;
        _isPremium = isPremium;
      });
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memuat data: $error')),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _openEditor({NoteFile? note}) async {
    if (note == null && !_isPremium && _notes.length >= freeFileLimit) {
      await _showFreeLimitDialog();
      return;
    }

    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => EditorScreen(noteFile: note),
      ),
    );

    if (result == true) {
      await _loadData();
    }
  }

  Future<void> _openPremiumScreen() async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => const PremiumScreen()),
    );

    if (result == true) {
      await _loadData();
    }
  }

  Future<void> _showFreeLimitDialog() async {
    await showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Batas Free Tercapai'),
          content: const Text(
            'Versi Free hanya bisa membuat maksimal 10 file. Upgrade ke Premium untuk membuat file tanpa batas.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Nanti dulu'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(context);
                _openPremiumScreen();
              },
              child: const Text('Upgrade'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _confirmDelete(NoteFile note) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Hapus catatan?'),
          content: Text('File "${note.displayName}" akan dihapus dari aplikasi.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Batal'),
            ),
            FilledButton.tonal(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Hapus'),
            ),
          ],
        );
      },
    );

    if (shouldDelete != true) return;

    try {
      await _fileService.deleteNote(note.path);
      await _loadData();

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Catatan berhasil dihapus.')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal menghapus catatan: $error')),
      );
    }
  }

  Future<void> _resetPremiumForTesting() async {
    await _premiumService.resetPremium();
    await _loadData();

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Status premium dikembalikan ke Free.')),
    );
  }

  String _formatSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    final kb = bytes / 1024;
    if (kb < 1024) return '${kb.toStringAsFixed(1)} KB';
    final mb = kb / 1024;
    return '${mb.toStringAsFixed(1)} MB';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final premiumLabel = _isPremium ? 'Premium' : 'Free';
    final usageLabel = _isPremium
        ? 'Unlimited file'
        : '${_notes.length}/$freeFileLimit file';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Text Editor'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'premium') {
                _openPremiumScreen();
              } else if (value == 'reset') {
                _resetPremiumForTesting();
              } else if (value == 'reload') {
                _loadData();
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'premium',
                child: Text('Upgrade Premium'),
              ),
              const PopupMenuItem(
                value: 'reload',
                child: Text('Refresh'),
              ),
              const PopupMenuItem(
                value: 'reset',
                child: Text('Reset Premium Dummy'),
              ),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _loadData,
          child: CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          child: Icon(
                            _isPremium
                                ? Icons.workspace_premium_outlined
                                : Icons.edit_note_outlined,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Status: $premiumLabel',
                                style: theme.textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(usageLabel),
                            ],
                          ),
                        ),
                        if (!_isPremium)
                          TextButton(
                            onPressed: _openPremiumScreen,
                            child: const Text('Upgrade'),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
              if (_isLoading)
                const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator()),
                )
              else if (_notes.isEmpty)
                SliverFillRemaining(
                  child: _EmptyState(onCreatePressed: () => _openEditor()),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 100),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, index) {
                        final note = _notes[index];

                        return Card(
                          elevation: 0,
                          child: ListTile(
                            leading: const Icon(Icons.description_outlined),
                            title: Text(note.displayName),
                            subtitle: Text(
                              'Ukuran ${_formatSize(note.sizeBytes)} • ${note.name}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            onTap: () => _openEditor(note: note),
                            trailing: IconButton(
                              tooltip: 'Hapus',
                              onPressed: () => _confirmDelete(note),
                              icon: const Icon(Icons.delete_outline),
                            ),
                          ),
                        );
                      },
                      childCount: _notes.length,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(),
        icon: const Icon(Icons.add),
        label: const Text('Catatan Baru'),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.onCreatePressed});

  final VoidCallback onCreatePressed;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.note_add_outlined,
              size: 72,
              color: theme.colorScheme.primary,
            ),
            const SizedBox(height: 16),
            Text(
              'Belum ada catatan',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Buat file teks pertama kamu dan simpan langsung di storage internal aplikasi.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: onCreatePressed,
              icon: const Icon(Icons.add),
              label: const Text('Buat Catatan'),
            ),
          ],
        ),
      ),
    );
  }
}
